# Markdown Package with Assets

![Knowledge asset flow](assets/knowledge-asset-flow.svg)

## Capture

- Keep source context.

## Structure

- Preserve related resources when supported.
