---
title: "AI Research Note — From Capture to Maintainable Markdown"
created: 2026-06-07
tags:
  - deminds
  - obsidian
  - markdown-assets
  - research-workflow
status: draft
source: "AI share + web article + local assets"
---

# AI Research Note — From Capture to Maintainable Markdown

> [!summary]
> This sample note shows how an Obsidian-style Markdown document can be prepared for DeMinds: clear headings, nested structure, assets, callouts, tasks, tables, and links that can later return to an Obsidian vault.

## 1. Why this note exists

A lot of valuable material starts outside the vault:

- an AI answer that is too useful to leave inside a chat thread;
- a web article that should become a long-term reference;
- a mind map that needs to become a writing outline;
- a Markdown folder with `assets/*` that should remain portable;
- local screenshots or demo videos that should be visible in preview.

DeMinds is useful before the note becomes permanent in Obsidian:

```text
Capture → DeMinds → Universal Mind Map → Markdown Preview → Export → Obsidian Vault
```

![Obsidian and DeMinds workflow](assets/obsidian-deminds-workflow.png)

## 2. The core idea

DeMinds is not replacing Obsidian.

It acts as a **structure-first staging area** before content enters a long-term vault.

### 2.1 What Obsidian is good at

- long-term note organization;
- backlinks and wiki links;
- tags and folders;
- daily notes and project notes;
- personal knowledge base maintenance.

### 2.2 What DeMinds adds before the vault

- turns AI, web, document, and mind map content into structure;
- shows content as a Universal Mind Map;
- keeps Markdown as the maintainable layer;
- previews assets before export;
- exports Markdown / PDF / full-map PNG when needed.

> [!tip]
> Use DeMinds when the content is not yet clean enough to become a permanent vault note.

## 3. Source material

| Source | Example | Why it needs staging |
| --- | --- | --- |
| AI answer | ChatGPT / Gemini / Doubao | Long, useful, but not yet organized |
| Web article | Blog / product analysis / X long post | Readable online, hard to maintain |
| Mind map | MindNode / XMind / FreeMind | Good hierarchy, not ideal for writing |
| Document | DOCX / HTML / TXT | Has content, but structure may be unclear |
| Markdown bundle | `note.md + assets/*` | Needs path checking and preview |

![Research note structure](assets/research-note-structure.png)

## 4. Working outline

### 4.1 Capture

Collect useful material first.

- Save the AI share.
- Keep the source URL.
- Put screenshots in `assets/`.
- Keep original files when they matter.

### 4.2 Structure

Bring the content into DeMinds and review it as a Universal Mind Map.

1. Check whether the hierarchy makes sense.
2. Remove repeated AI phrasing.
3. Promote important points into headings.
4. Keep examples as nested notes.
5. Preserve useful links.

### 4.3 Maintain

Return to Markdown and keep editing.

- rewrite vague headings;
- split long paragraphs;
- add context;
- convert raw notes into sections;
- keep assets close to the note.

### 4.4 Export or return to vault

After the note is clean enough:

- export Markdown with assets;
- export PDF for reading or delivery;
- export full-map PNG for visual review;
- move the final Markdown folder into Obsidian.

## 5. Obsidian-style links

This sample keeps common Obsidian conventions while remaining readable as standard Markdown.

- Related note: [[Project Knowledge Base]]
- Related workflow: [[Markdown Asset Pipeline]]
- Related source: [[AI Share Archive]]
- Tag group: #research-workflow #markdown-assets #local-first

> [!note]
> Wiki links are useful inside Obsidian. If another tool does not resolve them, they still remain readable as text.

## 6. Tasks

- [x] Capture the AI answer
- [x] Add source screenshots to `assets/`
- [ ] Review the Universal Mind Map in DeMinds
- [ ] Clean the Markdown structure
- [ ] Export Markdown package
- [ ] Move the cleaned note into the Obsidian vault

## 7. Example asset references

Standard Markdown image link:

```md
![Workflow](assets/obsidian-deminds-workflow.png)
```

Obsidian-style embed:

```md
![[assets/research-note-structure.png]]
```

Local video reference example:

```html
<video controls src="assets/demo-video.mp4"></video>
```

> [!warning]
> The sample package does not include a real video file. It only shows where a local video reference would live.

## 8. Why this matters

The goal is not to collect more content.

The goal is to make content usable again:

- visible as structure;
- editable as Markdown;
- portable as a folder;
- exportable as PDF or PNG;
- ready to become part of a long-term Obsidian vault.

## 9. Final summary

DeMinds and Obsidian can work together naturally:

> DeMinds helps content become structured and maintainable.  
> Obsidian helps that content stay connected and useful over time.

Use DeMinds before the vault when material is messy, long, multi-source, or asset-heavy.
Use Obsidian after the vault when the note is ready for long-term knowledge management.
