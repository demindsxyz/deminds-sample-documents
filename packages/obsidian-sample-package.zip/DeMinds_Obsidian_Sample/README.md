# DeMinds × Obsidian Sample Package

This sample package demonstrates a typical Obsidian-friendly Markdown note that is also suitable for DeMinds structure preview.

## Files

- `AI-Research-Note-DeMinds-to-Obsidian.md`
- `assets/obsidian-deminds-workflow.png`
- `assets/research-note-structure.png`

## Usage

1. Open or import the Markdown file in DeMinds.
2. Review the structure as a Universal Mind Map.
3. Open Markdown Preview and check images / assets.
4. Export Markdown, PDF, or full-map PNG if needed.
5. Move the cleaned Markdown folder into an Obsidian vault for long-term management.
