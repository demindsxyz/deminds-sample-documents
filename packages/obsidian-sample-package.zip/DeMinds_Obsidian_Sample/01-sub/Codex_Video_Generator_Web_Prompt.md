# Codex Prompt — DeMinds Video Generator Web Tool

你现在负责为 DeMinds 项目实现一个本地网页化的视频生成工具。

## 背景

当前项目中已经有一套完整的 DeMinds 视频模板系统，位于：

```text
scripts/video-generator/*
```

这个目录中包含之前整理好的完整版资源与实现基础，包括：

- DeMinds 标准封面 / 封尾 overlay
- MacBook Air 13 / iPad 13 横屏适配素材
- Cafe 风格背景音乐
- ffmpeg 合成脚本
- 命令说明文档
- 当前标准模板规则：浅色背景、不对称单条点线连接、底部 Logo + DeMinds 水平居中对齐、标题/副标题动态生成、Cafe 音乐

请以 `scripts/video-generator/*` 为唯一基础，不要重新设计另一套模板系统。先完整阅读该目录下的脚本、素材和文档，然后在此基础上扩展一个本地网页功能。

## 目标

实现一个本地网页功能，用于生成 DeMinds 标准风格演示视频。网页应调用 `scripts/video-generator/*` 中已有的后台命令或 Node/脚本封装后的 ffmpeg 流程，不要只做前端静态表单。

## 功能入口

建议新增一个本地工具页面，例如：

```text
/tools/video-generator
```

或在现有开发工具路由中新增：

```text
Video Generator
```

## 核心流程

用户在网页中选择或填写参数 → 点击 Generate → 后台调用 `scripts/video-generator` 中的视频生成流程 → 页面显示任务状态 → 完成后提供输出视频路径和预览/下载入口。

## 默认场景

以 DeMinds 标准模板转换为默认模式：

- 原视频来自 `/video-sources/*`
- 默认使用 classic overlay
- 默认背景色 `#F4EFE6`
- 默认音乐 DeMinds Cafe classic light
- 默认封面 2 秒
- 默认封尾 3 秒
- 默认播放速度 1.0x
- 默认输出 MP4
- 默认按原视频宽高生成画布，除非用户选择 Mac 13 / iPad 13 preset
- 默认保留当前 DeMinds 标准品牌风格

## 必须支持的参数

### 1. 原视频路径

- 从 `/video-sources/*` 读取可用视频列表
- 支持手动输入路径
- 支持 `mp4`、`mov`、`m4v`
- 输出路径默认到 `/video-outputs/*`

### 2. 播放速度

- 1.0x
- 1.5x
- 2.0x
- 后台 ffmpeg 要正确处理视频速度：
  - 1.5x: `setpts=PTS/1.5`
  - 2.0x: `setpts=PTS/2`
- 默认移除原声，仅使用背景音乐
- 如后续保留原声，需要同步处理 `atempo`，但第一阶段可以不做

### 3. 封面 / 封尾模板选择

- 使用 `scripts/video-generator` 中已有 overlay
- 至少支持 `classic` / `clean` / `structure` 或目录中已有的模板枚举
- 默认 `classic`
- `classic` 必须使用当前标准：原版风格、不对称、单条、轻量点线连接
- 不要使用对称多线网络作为默认模板

### 4. 背景颜色选择

- 默认 `#F4EFE6`
- 提供预设：
  - Default Warm: `#F4EFE6`
  - Clean Light: `#F7F4EE`
  - Soft Grey: `#F3F1EC`
- 支持自定义 hex 色值
- 背景色由 ffmpeg `color` filter 动态生成，不写死在 PNG 中

### 5. 音乐选择

- 从 `scripts/video-generator` 中已有 music 目录读取
- 默认 DeMinds Cafe classic light
- 支持关闭音乐
- 支持音乐音量设置，默认 0.42
- 音乐应自动循环、按总时长截断、淡入淡出

### 6. 封面文案

- Cover title
- Cover subtitle
- 支持为空；为空时仍生成品牌封面，但不显示对应文字
- 文字通过 ffmpeg `drawtext` 动态写入，不烘焙进 overlay

### 7. 封尾文案

- Outro title
- Outro subtitle
- 支持为空
- 文字通过 ffmpeg `drawtext` 动态写入

### 8. 标题字体大小

- 提供默认、较小、较大三档
- 或提供数值倍率：
  - `titleScale`，默认 1.0
  - `subtitleScale`，默认 1.0
- 兼容不同宽高比
- 标题默认尽量单行显示
- 如实现自动换行，必须保持居中、行距克制

### 9. 输出选项

- 输出文件名
- 输出目录
- 质量档位：
  - high: crf 21-22
  - standard: crf 23
  - compact: crf 25 或限制码率
- 支持“控制 20MB 内”选项
  - 开启时使用码率控制策略
  - 适合 X / 微博 / 小红书发布

### 10. 画布尺寸策略

- input：按原视频宽高，默认
- mac13-retina：2560×1600
- mac13-points：1280×800
- ipad13-landscape：使用 `scripts/video-generator` 中已有 iPad 13 横屏规格
- custom：用户输入宽高
- 自动按所选画布匹配 overlay

## 后台实现要求

### 1. 不要直接在前端拼 shell 字符串

- 后端必须使用参数白名单
- `template`、`music`、`speed`、`quality`、`canvasPreset` 使用枚举
- 路径限制：
  - 输入只允许 `/video-sources/`
  - 输出只允许 `/video-outputs/`
  - 模板和音乐只允许 `scripts/video-generator` 内部资源

### 2. 优先复用 scripts/video-generator 中已有脚本

- 如果已有 shell 脚本可直接满足需求，请先封装调用
- 如需要增强，新增一个 Node wrapper，例如：

```text
scripts/video-generator/generateVideo.ts
```

接收 JSON 参数：

```json
{
  "inputPath": "video-sources/demo.mp4",
  "outputName": "demo_output.mp4",
  "canvasPreset": "input",
  "speed": 1.5,
  "template": "classic",
  "backgroundColor": "#F4EFE6",
  "music": "classic-light",
  "musicVolume": 0.42,
  "coverTitle": "Bring AI Conversations into Your Workspace",
  "coverSubtitle": "Use the Share Sheet to send useful AI output into DeMinds, then continue working.",
  "outroTitle": "Keep Useful AI Conversations Working",
  "outroSubtitle": "Turn shared AI output into editable structure, Markdown preview, and portable PDF.",
  "titleScale": 1.0,
  "subtitleScale": 1.0,
  "quality": "standard",
  "targetUnder20MB": false
}
```

### 3. ffmpeg 调用

- 使用 `child_process.spawn`，不要 `exec` 拼接大字符串
- 参数数组化
- 捕获 stdout/stderr
- 返回任务状态和错误信息

### 4. ffmpeg 逻辑应复用并保持现有能力

- 读取原视频宽高和时长
- 生成 `cover_rendered.mp4`
- 生成 `main_normalized.mp4`
- 根据 `speed` 调整视频速度
- 默认移除原声
- 生成 `outro_rendered.mp4`
- concat 三段
- 音乐 `stream_loop -1`
- volume 默认 0.42
- afade in/out
- `movflags +faststart`
- 输出 H.264 + AAC MP4

### 5. 字体处理

- 优先复用 `scripts/video-generator` 中现有字体配置
- macOS 默认可用字体可作为 fallback：
  - `/System/Library/Fonts/Supplemental/Arial Bold.ttf`
  - `/System/Library/Fonts/Supplemental/Arial.ttf`
- drawtext 中需要正确转义引号、冒号、逗号、百分号等特殊字符

## UI 要求

- 风格保持 DeMinds 工具页的简洁风格
- 左侧或上方为参数表单
- 右侧显示：
  - 当前模板预览
  - 输入视频信息：宽高、时长、大小
  - 输出预估信息
  - 生成日志
  - 完成后的视频预览
- 提供“一键使用默认模板”按钮
- 提供“保存配置为 JSON”与“加载配置 JSON”
- 提供“复制 CLI 命令”功能，便于脱离网页复现

## 内置 preset

### Preset A: AI Share

Cover Title:

```text
Bring AI Conversations into Your Workspace
```

Cover Subtitle:

```text
Use the Share Sheet to send useful AI output into DeMinds, then continue working.
```

Outro Title:

```text
Keep Useful AI Conversations Working
```

Outro Subtitle:

```text
Turn shared AI output into editable structure, Markdown preview, and portable PDF.
```

### Preset B: X Article

Cover Title:

```text
Share an article from X into DeMinds.
```

Cover Subtitle:

```text
Bring the content into a structured workspace.
```

Outro Title:

```text
Review the result before exporting.
```

Outro Subtitle:

```text
Save a clean PDF when the content is ready to carry forward.
```

### Preset C: Markdown Videos

Cover Title:

```text
MARKDOWN VIDEOS, PREVIEWED SAFELY
```

Cover Subtitle:

```text
Keep video references in Markdown. Play them in DeMinds Preview.
```

Outro Title:

```text
PLAYABLE IN PREVIEW. CLEAN IN MARKDOWN.
```

Outro Subtitle:

```text
DeMinds keeps media visible, without polluting your document structure.
```

### Preset D: Focus / Presentation

Cover Title:

```text
Zoom Into What Matters
```

Cover Subtitle:

```text
Focus on any branch, then play through the structure step by step.
```

Outro Title:

```text
Focused. Structured. Ready to Present.
```

Outro Subtitle:

```text
Turn complex ideas into maintainable Markdown.
```

## 文档要求

请同步更新或新增：

```text
docs/VIDEO_GENERATOR_WEB.md
```

内容包括：

- 如何启动网页工具
- `/video-sources/` 与 `/video-outputs/` 目录规则
- 参数说明
- preset 说明
- 如何用命令行复现
- ffmpeg 依赖检查
- MacBook Air 13 / iPad 13 横屏录屏推荐设置
- `scripts/video-generator/*` 的资源结构说明

## 质量要求

- 不破坏 `scripts/video-generator` 中现有命令行脚本
- 新网页功能只是包装和增强
- 原有 shell 脚本仍可独立使用
- TypeScript 类型完整
- 错误提示清晰
- 不引入大型 UI 框架，除非项目已有
- 尽量使用现有 CSS/组件风格

## 验收标准

- 可以从 `/video-sources/` 选择一个 mp4/mov
- 可以生成默认模板视频
- 可以切换音乐
- 可以切换背景色
- 可以修改封面/封尾标题和副标题
- 可以选择 1.0x / 1.5x / 2.0x
- 可以选择 canvas preset
- 可以输出到 `/video-outputs/`
- 输出视频包含封面、变速后的原视频、封尾、背景音乐
- Logo + DeMinds 品牌区保持水平居中对齐
- classic 模板使用原版不对称单条点线连接
- 生成结果可在网页中预览
- 终端和网页日志中都能看到 ffmpeg 执行进度或错误

## 第一阶段范围

第一阶段请只完成本地可用的最小闭环：

```text
读取 /video-sources → 表单配置 → 调用 scripts/video-generator 流程 → 输出 /video-outputs → 网页预览
```

不要先做队列、历史记录、批量生成、云端上传或复杂权限系统。
